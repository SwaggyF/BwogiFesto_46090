/* 
 * File:   main.cpp
 * Author: Festo Bwogi
 * Created on June 25, 2015, 11:18 AM
 * Purpose: Violent crimes
 */
 
 
#include <iostream>
using namespace std;
 
 
//User Libraries
 
//Global constants
 
//Function Prototypes
 
//Execution Begins
int main(int argc, char** argv) {
    //Declare variables Here
    float USviocr = 11.88;//U.S number of violent crimes
    float USpop = 318;//U.S population
    float UKviocr = 6.52;//UK number of violent crimes
    float UKpop = 64.1;//UK population
    float percentage;//violent crime decimal multiply 100
    //Process Input Here
    percentage=USviocr/USpop * 100;//Units = %
    cout<<"US number of violent crimes = 11.88"<<" USviocr"<<endl;   
    cout<<"US population = 318"<<" USpop"<<endl;
    cout<<"US percentage = %"<<percentage<<endl;
    percentage=UKviocr/UKpop * 100;//Units = %
    cout<<"UK number of violent crimes = 6.52"<<"UKviocr"<<endl;   
    cout<<"UK population = 64.1"<<"UKpop"<<endl;
    cout<<"UK percentage = %"<<percentage<<endl;
    //Initialize values
  
    return 0;
}
 
